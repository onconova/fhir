# Primary Cancer Recurrence Type - Onconova Implementation Guide v1.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Primary Cancer Recurrence Type**

## Extension: Primary Cancer Recurrence Type 

| | |
| :--- | :--- |
| *Official URL*:http://onconova.github.io/fhir/StructureDefinition/onconova-ext-primary-cancer-recurrence-type | *Version*:1.3.0 |
| Active as of 2026-04-15 | *Computable Name*:PrimaryCancerRecurrenceType |

Indicates the type of recurrence for the condition (local or regional).

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Primary Cancer Condition Profile](StructureDefinition-onconova-primary-cancer-condition.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/onconova.fhir|current/StructureDefinition/onconova-ext-primary-cancer-recurrence-type)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onconova-ext-primary-cancer-recurrence-type.csv), [Excel](StructureDefinition-onconova-ext-primary-cancer-recurrence-type.xlsx), [Schematron](StructureDefinition-onconova-ext-primary-cancer-recurrence-type.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onconova-ext-primary-cancer-recurrence-type",
  "url" : "http://onconova.github.io/fhir/StructureDefinition/onconova-ext-primary-cancer-recurrence-type",
  "version" : "1.3.0",
  "name" : "PrimaryCancerRecurrenceType",
  "title" : "Primary Cancer Recurrence Type",
  "status" : "active",
  "date" : "2026-04-15T19:05:31+00:00",
  "publisher" : "Onconova",
  "contact" : [{
    "name" : "Onconova",
    "telecom" : [{
      "system" : "url",
      "value" : "http://onconova.github.io/docs"
    }]
  }],
  "description" : "Indicates the type of recurrence for the condition (local or regional).",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "http://onconova.github.io/fhir/StructureDefinition/onconova-primary-cancer-condition#Condition.clinicalStatus.extension"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Primary Cancer Recurrence Type",
      "definition" : "Indicates the type of recurrence for the condition (local or regional)."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://onconova.github.io/fhir/StructureDefinition/onconova-ext-primary-cancer-recurrence-type"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://onconova.github.io/fhir/ValueSet/onconova-vs-recurrence-types"
      }
    }]
  }
}

```
