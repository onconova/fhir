# Comorbidities Profile - Onconova Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Comorbidities Profile**

## Resource Profile: Comorbidities Profile 

| | |
| :--- | :--- |
| *Official URL*:http://onconova.github.io/fhir/StructureDefinition/onconova-comorbidities | *Version*:0.2.0 |
| Active as of 2026-02-25 | *Computable Name*:OnconovaComorbidities |

 
A profile representing comorbidities for a cancer patient, i.e. other health conditions that exist alongside the primary cancer diagnosis. Supports existing comorbidity panels such as the Charlson Comorbidity Index (CCI) and Elixhauser Comorbidity Index (ECI) with comorbidity indexes. 
The profile constrains the mCODE [Comorbidities profile](http://hl7.org/fhir/us/mcode/StructureDefinition/mcode-comorbidities) to ensure consistent use of ICD-10 codes for documenting comorbid conditions, and to link the comorbidity information to the Onconova primary cancer condition profile. 
**Conformance:** 
Observation resources representing a generic or panel comorbidities assessment in the scope of Onconova SHALL conform to this profile. Any resource intended to conform to this profile SHOULD populate `meta.profile` accordingly. 

**Usages:**

* CapabilityStatements using this Profile: [Onconova FHIR REST Server Capability Statement](CapabilityStatement-onconova-capability-statement.md)
* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/onconova.fhir|current/StructureDefinition/onconova-comorbidities)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onconova-comorbidities.csv), [Excel](StructureDefinition-onconova-comorbidities.xlsx), [Schematron](StructureDefinition-onconova-comorbidities.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onconova-comorbidities",
  "url" : "http://onconova.github.io/fhir/StructureDefinition/onconova-comorbidities",
  "version" : "0.2.0",
  "name" : "OnconovaComorbidities",
  "title" : "Comorbidities Profile",
  "status" : "active",
  "date" : "2026-02-25T15:12:31+00:00",
  "publisher" : "Onconova",
  "contact" : [{
    "name" : "Onconova",
    "telecom" : [{
      "system" : "url",
      "value" : "http://onconova.github.io/docs"
    }]
  }],
  "description" : "A profile representing comorbidities for a cancer patient, i.e. other health conditions that exist alongside the primary cancer diagnosis. Supports existing comorbidity panels such as the Charlson Comorbidity Index (CCI) and Elixhauser Comorbidity Index (ECI) with comorbidity indexes.\n\nThe profile constrains the mCODE [Comorbidities profile](http://hl7.org/fhir/us/mcode/StructureDefinition/mcode-comorbidities) to ensure consistent use of ICD-10 codes for documenting comorbid conditions, and to link the comorbidity information to the Onconova primary cancer condition profile. \n\n**Conformance:**\n\nObservation resources representing a generic or panel comorbidities assessment in the scope of Onconova SHALL conform to this profile. Any resource intended to conform to this profile SHOULD populate `meta.profile` accordingly. ",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/us/mcode/StructureDefinition/mcode-comorbidities",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "constraint" : [{
        "key" : "com-1",
        "severity" : "error",
        "human" : "If an index score is provided, then the comorbidity panel method must also be provided.",
        "expression" : "valueQuantity.exists() implies method.exists()",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-comorbidities"
      },
      {
        "key" : "com-req-1",
        "severity" : "error",
        "human" : "The subject element is required and must be provided.",
        "expression" : "subject.exists()",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-comorbidities"
      },
      {
        "key" : "com-req-2",
        "severity" : "error",
        "human" : "The effectiveDateTime element is required and must be provided.",
        "expression" : "effectiveDateTime.exists() and effectiveDateTime.hasValue()",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-comorbidities"
      },
      {
        "key" : "com-req-3",
        "severity" : "error",
        "human" : "The focus element is required and must be provided.",
        "expression" : "focus.exists()",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-comorbidities"
      }]
    },
    {
      "id" : "Observation.extension:comorbidConditionPresent",
      "path" : "Observation.extension",
      "sliceName" : "comorbidConditionPresent"
    },
    {
      "id" : "Observation.extension:comorbidConditionPresent.value[x]",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://onconova.github.io/fhir/ValueSet/onconova-vs-icd-10-conditions"
      }
    },
    {
      "id" : "Observation.extension:comorbidConditionAbsent",
      "path" : "Observation.extension",
      "sliceName" : "comorbidConditionAbsent"
    },
    {
      "id" : "Observation.extension:comorbidConditionAbsent.value[x]",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.extension.value[x]",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://onconova.github.io/fhir/ValueSet/onconova-vs-icd-10-conditions"
      }
    },
    {
      "id" : "Observation.basedOn",
      "path" : "Observation.basedOn",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.partOf",
      "path" : "Observation.partOf",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.subject",
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/core/StructureDefinition/uscdi-requirement",
        "valueBoolean" : true
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        },
        {
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        },
        {
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://onconova.github.io/fhir/StructureDefinition/onconova-cancer-patient"]
      }]
    },
    {
      "id" : "Observation.focus",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.focus",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://onconova.github.io/fhir/StructureDefinition/onconova-primary-cancer-condition"]
      }]
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.effective[x]",
      "path" : "Observation.effective[x]",
      "min" : 1,
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-type-must-support",
          "valueBoolean" : true
        }],
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Observation.issued",
      "path" : "Observation.issued",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.value[x]",
      "extension" : [{
        "url" : "http://hl7.org/fhir/us/core/StructureDefinition/uscdi-requirement",
        "valueBoolean" : true
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.value[x]",
      "short" : "Comorbidity Index Score",
      "type" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-type-must-support",
          "valueBoolean" : true
        },
        {
          "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-type-must-support",
          "valueBoolean" : true
        }],
        "code" : "Quantity"
      }]
    },
    {
      "id" : "Observation.value[x].unit",
      "path" : "Observation.value[x].unit",
      "patternString" : "1"
    },
    {
      "id" : "Observation.interpretation",
      "path" : "Observation.interpretation",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.method",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.method",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://onconova.github.io/fhir/ValueSet/onconova-vs-comorbidity-panels"
      }
    },
    {
      "id" : "Observation.referenceRange",
      "path" : "Observation.referenceRange",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.derivedFrom",
      "path" : "Observation.derivedFrom",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    }]
  }
}

```
