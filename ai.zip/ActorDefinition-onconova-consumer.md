# Consumer (Onconova) - Onconova Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Consumer (Onconova)**

## ActorDefinition: Consumer (Onconova) 

| | |
| :--- | :--- |
| *Official URL*:http://onconova.github.io/fhir/ActorDefinition/onconova-consumer | *Version*:0.2.0 |
| Active as of 2026-03-18 | *Computable Name*: |

 
An actor representing a data consumer that interacts with the Onconova FHIR REST server to retrieve and read patient case data. 

