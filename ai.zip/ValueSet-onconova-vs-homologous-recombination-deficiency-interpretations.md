# Homologous Recombination Deficiency Interpretation Value Set - Onconova Implementation Guide v1.3.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Homologous Recombination Deficiency Interpretation Value Set**

## ValueSet: Homologous Recombination Deficiency Interpretation Value Set 

| | |
| :--- | :--- |
| *Official URL*:http://onconova.github.io/fhir/ValueSet/onconova-vs-homologous-recombination-deficiency-interpretations | *Version*:1.3.0 |
| Active as of 2026-04-15 | *Computable Name*:HomologousRecombinationDeficiencyInterpretations |

 
The categorical classifications of the HRD status interpreted from its value.. 

 **References** 

* [Homologous Recombination Deficiency Interpretation](StructureDefinition-onconova-ext-homologous-recombination-deficiency-interpretation.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "onconova-vs-homologous-recombination-deficiency-interpretations",
  "url" : "http://onconova.github.io/fhir/ValueSet/onconova-vs-homologous-recombination-deficiency-interpretations",
  "version" : "1.3.0",
  "name" : "HomologousRecombinationDeficiencyInterpretations",
  "title" : "Homologous Recombination Deficiency Interpretation Value Set",
  "status" : "active",
  "date" : "2026-04-15T07:47:05+00:00",
  "publisher" : "Onconova",
  "contact" : [{
    "name" : "Onconova",
    "telecom" : [{
      "system" : "url",
      "value" : "http://onconova.github.io/docs"
    }]
  }],
  "description" : "The categorical classifications of the HRD status interpreted from its value..",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "10828004",
        "display" : "Positive (qualifier value)"
      },
      {
        "code" : "260385009",
        "display" : "Negative (qualifier value)"
      },
      {
        "code" : "82334004",
        "display" : "Indeterminate (qualifier value)"
      }]
    }]
  }
}

```
