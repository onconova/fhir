# Creator (Onconova) - JSON Representation - Onconova Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Creator (Onconova)**

## : Creator (Onconova) - JSON Representation

| |
| :--- |
| Active as of 2026-02-25 |

[Raw json](ActorDefinition-onconova-creator.json) | [Download](ActorDefinition-onconova-creator.json)

