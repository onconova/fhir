# Consumer (Onconova) - JSON Representation - Onconova Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Consumer (Onconova)**

## : Consumer (Onconova) - JSON Representation

| |
| :--- |
| Active as of 2025-11-25 |

[Raw json](ActorDefinition-onconova-consumer.json) | [Download](ActorDefinition-onconova-consumer.json)

