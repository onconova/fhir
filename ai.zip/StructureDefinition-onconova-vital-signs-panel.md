# Vital Signs Panel Profile - Onconova Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Vital Signs Panel Profile**

## Resource Profile: Vital Signs Panel Profile 

| | |
| :--- | :--- |
| *Official URL*:http://onconova.github.io/fhir/StructureDefinition/onconova-vital-signs-panel | *Version*:0.2.0 |
| Active as of 2026-02-25 | *Computable Name*:OnconovaVitalSignsPanel |

 
A profile representing a collection of vital signs measurements. 
Since Onconova does not represent individual vital signs as separate observations, this profile aggregates multiple vital signs into a single Observation resource that can be uniquely identified. It extends the [Hl7 FHIR VitalsPanel profile](http://hl7.org/fhir/StructureDefinition/vitalspanel) to include specific constraints and requirements for Onconova. 
**Conformance:** 
Observation resources representing a collection of vital signs in the scope of Onconova SHALL conform to this profile. Any resource intended to conform to this profile SHOULD populate `meta.profile` accordingly. 

**Usages:**

* CapabilityStatements using this Profile: [Onconova FHIR REST Server Capability Statement](CapabilityStatement-onconova-capability-statement.md)
* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/onconova.fhir|current/StructureDefinition/onconova-vital-signs-panel)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-onconova-vital-signs-panel.csv), [Excel](StructureDefinition-onconova-vital-signs-panel.xlsx), [Schematron](StructureDefinition-onconova-vital-signs-panel.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "onconova-vital-signs-panel",
  "url" : "http://onconova.github.io/fhir/StructureDefinition/onconova-vital-signs-panel",
  "version" : "0.2.0",
  "name" : "OnconovaVitalSignsPanel",
  "title" : "Vital Signs Panel Profile",
  "status" : "active",
  "date" : "2026-02-25T15:12:31+00:00",
  "publisher" : "Onconova",
  "contact" : [{
    "name" : "Onconova",
    "telecom" : [{
      "system" : "url",
      "value" : "http://onconova.github.io/docs"
    }]
  }],
  "description" : "A profile representing a collection of vital signs measurements. \n\nSince Onconova does not represent individual vital signs as separate observations, this profile aggregates multiple vital signs into a single Observation resource that can be uniquely identified.\nIt extends the [Hl7 FHIR VitalsPanel profile](http://hl7.org/fhir/StructureDefinition/vitalspanel) to include specific constraints and requirements for Onconova.\n\n**Conformance:**\n\nObservation resources representing a collection of vital signs in the scope of Onconova SHALL conform to this profile. Any resource intended to conform to this profile SHOULD populate `meta.profile` accordingly. ",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/vitalspanel",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "constraint" : [{
        "key" : "o-vit-req-1",
        "severity" : "error",
        "human" : "The subject element is required and must be provided.",
        "expression" : "subject.exists()",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-vital-signs-panel"
      },
      {
        "key" : "o-vit-req-2",
        "severity" : "error",
        "human" : "The effectiveDateTime element is required and must be provided.",
        "expression" : "effectiveDateTime.exists() and effectiveDateTime.hasValue()",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-vital-signs-panel"
      },
      {
        "key" : "o-vit-req-3",
        "severity" : "error",
        "human" : "At least one vital sign profile must be referenced.",
        "expression" : "hasMember.exists() and hasMember.count() > 0",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-vital-signs-panel"
      },
      {
        "key" : "o-vit-req-4",
        "severity" : "error",
        "human" : "The value[x] element must not be set for the vitals panel.",
        "expression" : "value.exists().not()",
        "source" : "http://onconova.github.io/fhir/StructureDefinition/onconova-vital-signs-panel"
      }]
    },
    {
      "id" : "Observation.status",
      "path" : "Observation.status",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.code",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.code",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "85353-1"
        }]
      }
    },
    {
      "id" : "Observation.subject",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.subject",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://onconova.github.io/fhir/StructureDefinition/onconova-cancer-patient"]
      }]
    },
    {
      "id" : "Observation.focus",
      "path" : "Observation.focus",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.effective[x]",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.effective[x]",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Observation.issued",
      "path" : "Observation.issued",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.interpretation",
      "path" : "Observation.interpretation",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.bodySite",
      "path" : "Observation.bodySite",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.specimen",
      "path" : "Observation.specimen",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.device",
      "path" : "Observation.device",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.referenceRange",
      "path" : "Observation.referenceRange",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    },
    {
      "id" : "Observation.hasMember",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:populate-if-known"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.hasMember",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "$this.resolve()"
        }],
        "description" : "Slice based on the component.code value",
        "rules" : "open"
      }
    },
    {
      "id" : "Observation.hasMember:body-temperature",
      "path" : "Observation.hasMember",
      "sliceName" : "body-temperature",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/bodytemp"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:body-height",
      "path" : "Observation.hasMember",
      "sliceName" : "body-height",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/bodyheight"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:body-weight",
      "path" : "Observation.hasMember",
      "sliceName" : "body-weight",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/bodyweight"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:bmi",
      "extension" : [{
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHALL:ignore"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-creator"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      },
      {
        "extension" : [{
          "url" : "code",
          "valueCode" : "SHOULD:persist"
        },
        {
          "url" : "actor",
          "valueCanonical" : "http://onconova.github.io/fhir/ActorDefinition/onconova-consumer"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/obligation"
      }],
      "path" : "Observation.hasMember",
      "sliceName" : "bmi",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/bmi"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.hasMember:blood-pressure",
      "path" : "Observation.hasMember",
      "sliceName" : "blood-pressure",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/bp"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.component",
      "path" : "Observation.component",
      "short" : "Not used in this profile",
      "definition" : "Not used in this profile"
    }]
  }
}

```
